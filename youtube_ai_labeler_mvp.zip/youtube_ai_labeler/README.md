# YouTube AI Labeler — MVP

A Chrome/Edge Manifest V3 extension prototype that adds cautious labels to YouTube video cards and watch pages.

## Labels
- **AI disclosure found**: visible page text contains common AI disclosure phrases. This is not independent verification.
- **AI status unknown**: no reliable signal was found. It does not mean the video is human-made.

## Install in Chrome or Edge
1. Extract this folder.
2. Open `chrome://extensions` in Chrome or `edge://extensions` in Edge.
3. Enable **Developer mode**.
4. Click **Load unpacked** and choose this folder (the one containing `manifest.json`).
5. Open or refresh YouTube.

## Limitations
This prototype does not inspect video pixels or audio, verify provenance, or prove that a video is AI-generated or human-made. YouTube's markup and disclosure text can change. Use as an interface prototype only, not for high-stakes decisions.

## Production roadmap
1. Use official platform disclosure and public metadata where permitted.
2. Check C2PA/content credentials or other provenance evidence where available.
3. Add frame/audio forensic models with documented benchmark performance.
4. Combine evidence into labels such as **Disclosed AI**, **Likely AI-assisted**, **Mixed/edited**, and **Unknown**.
5. Show source, timestamp, confidence, and why the label was assigned; support corrections and audits.
6. Minimize data collection and do not upload users' watch history or media by default.
