# YouTube AI Labeler v0.2

A Chrome/Edge Manifest V3 prototype that annotates YouTube video cards and watch pages with cautious AI-origin labels. It checks visible disclosure text and can optionally call a local evidence service.

## Honest status model
- **Disclosure signal**: visible page text contains a likely disclosure phrase. This verifies only that the phrase was found, not the video's true origin.
- **Disclosed AI**: reserved for an authenticated platform/creator disclosure whose source is recorded by the evidence service.
- **Likely AI-assisted**: probabilistic conclusion requiring multiple validated detectors and calibrated thresholds. Not implemented as a forensic classifier in this MVP.
- **AI status unknown**: insufficient evidence; not a human-made verdict.

## Install extension
1. Extract this folder.
2. Open `chrome://extensions` in Chrome or `edge://extensions` in Edge.
3. Enable Developer mode.
4. Choose **Load unpacked** and select this folder.
5. Open YouTube and refresh.

The browser extension works without the optional service, but then only visible text is checked.

## Optional local evidence API
Python 3.10+ recommended.

```bash
cd backend
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8765
```

This API is a safe integration scaffold. It returns `Unknown` unless an explicit disclosure signal is provided; it does not pretend to run a trained video/audio detector. The next stage is to integrate tested detector models and provenance verification behind the interfaces.

## Production architecture
1. Browser extension extracts the public video ID and visible page text only.
2. Evidence API obtains permitted metadata and records source, timestamp, and evidence type.
3. Provenance adapter validates signed content credentials when accessible; missing credentials are neutral, not evidence of AI.
4. Video detector samples frames from media provided with appropriate rights/permission; audio detector evaluates permitted audio input. Keep model name/version, calibrated score, and input hash.
5. Fusion layer combines independent signals and outputs evidence plus calibrated uncertainty.
6. Feedback/audit pipeline tracks false positives/negatives and model drift.

Do not download or bypass access controls on YouTube media. A production deployment must respect YouTube terms, privacy law, copyright, detector licenses, and data minimization. Browser-extension DOM selectors and disclosure wording may change.
