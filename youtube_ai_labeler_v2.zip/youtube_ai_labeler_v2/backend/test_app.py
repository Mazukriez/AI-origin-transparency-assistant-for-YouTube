from fastapi.testclient import TestClient
from app import app

client = TestClient(app)

def test_health_reports_detector_not_configured():
    r = client.get('/health')
    assert r.status_code == 200
    assert r.json()['detectors'] == 'not_configured'

def test_unknown_is_not_claimed_human_made():
    r = client.post('/v1/assess', json={'video_id':'abcdefghijk', 'visible_page_text':'ordinary video description'})
    assert r.status_code == 200
    assert r.json()['label'] == 'Unknown'
    assert r.json()['confidence'] is None
    assert 'does not mean human-made' in r.json()['explanation']

def test_disclosure_phrase_is_only_a_signal():
    r = client.post('/v1/assess', json={'video_id':'abcdefghijk', 'visible_page_text':'Altered or synthetic content'})
    assert r.status_code == 200
    assert r.json()['label'] == 'Disclosed AI'
    assert r.json()['evidence'][0]['verified'] is False
    assert 'not independent forensic verification' in r.json()['explanation']

def test_invalid_video_id_rejected():
    r = client.post('/v1/assess', json={'video_id':'bad id!', 'visible_page_text':''})
    assert r.status_code == 422
