chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ ytalEnabled: true, ytalApiBase: 'http://127.0.0.1:8765' });
});
