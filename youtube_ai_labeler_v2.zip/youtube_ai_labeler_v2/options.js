const api = document.getElementById('api');
const status = document.getElementById('status');
chrome.storage.local.get({ytalApiBase:'http://127.0.0.1:8765'}, v => api.value = v.ytalApiBase);
document.getElementById('save').addEventListener('click', () => {
  const value = api.value.trim().replace(/\/$/, '');
  if (!/^https?:\/\//.test(value)) { status.textContent = 'Enter a valid http(s) URL.'; return; }
  chrome.storage.local.set({ytalApiBase:value}, () => { status.textContent = 'Saved. Reload YouTube to apply.'; });
});
