# Privacy notice for the developer preview

- The extension reads visible text in YouTube pages to find disclosure phrases.
- When a video card does not contain a recognized phrase and has a video ID, the extension may send that ID and up to 12,000 characters of visible card text to the configured local API.
- The default API address is `http://127.0.0.1:8765`, which refers to the same computer. The service is not intended to be internet-accessible.
- This preview does not download video or audio, and does not upload media files.
- There is no hosted service, account, analytics, or telemetry included in this source package.
- Review this notice and update it before adding hosted processing, analytics, accounts, or media uploads.
