# YouTube AI Labeler — Evidence Preview v0.3.0

A Chrome/Edge Manifest V3 extension prototype that adds evidence-aware labels to YouTube. **This is not yet a public-ready AI detector.** The working build detects visible disclosure phrases and deliberately reports `AI status unknown` when no reliable signal is available.

## What works now
- Manifest V3 extension for Chrome and Edge.
- Adds badges to YouTube browse/watch UI and dynamically loaded cards.
- Detects a small set of visible AI/altered-content disclosure phrases.
- Optional local FastAPI evidence endpoint; the API defaults to loopback only.
- `/health` and `/v1/capabilities` clearly list active/inactive detector modules.
- Test-covered fusion policy for future calibrated video + audio detector outputs.
- `Unknown` never means human-made. Disclosure text is never styled as verified provenance.

## What is not implemented yet
- No actual frame-level AI-generation classifier.
- No actual synthetic-speech/audio classifier.
- No C2PA signature/manifest verification.
- No YouTube media downloading or automatic extraction. A production system should use permitted/consented media paths and respect platform terms, copyright, privacy, and regional law.
- The fusion module is a policy gate/test fixture, not a media detector. The 0.80 threshold is a placeholder and must be selected using validation data before release.

## Install extension locally
1. Extract the ZIP.
2. Chrome: open `chrome://extensions`. Edge: open `edge://extensions`.
3. Turn on **Developer mode**.
4. Choose **Load unpacked** and select this folder (the folder containing `manifest.json`).
5. Open or refresh YouTube.
6. Optional: start the local API below. Without it, the extension still detects visible disclosure phrases and labels other videos unknown.

## Start the local API (Windows PowerShell)
From the extracted `youtube_ai_labeler_v3` folder:

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8765
```

Check `http://127.0.0.1:8765/health` and `http://127.0.0.1:8765/v1/capabilities`. Keep the host at `127.0.0.1` for local testing; do not expose this development API directly to the internet.

## Run tests
In a second PowerShell terminal, from `backend` with the venv active:

```powershell
pytest -v
```

## Evidence taxonomy
| UI label | Meaning | Is it proof? |
|---|---|---|
| Disclosure signal | A matching phrase appears in visible YouTube/page text | No; text can be incomplete, changed, or misleading |
| Verified AI provenance | Reserved for a future cryptographically verified credential/manifest with a trustworthy AI-origin assertion | Only for the specific authenticated assertion; does not prove every edit or scene |
| Likely AI-assisted | Reserved for future calibrated video and audio classifiers that agree under a validated policy | No; probabilistic estimate |
| AI status unknown | Evidence is absent, unavailable, conflicting, or insufficient | No conclusion about human vs AI origin |

C2PA Content Credentials can help attest to media source/history, but absence of credentials is not proof of human creation. A verified signature authenticates an assertion chain; interpretation depends on what was asserted and the trust policy.

## Next production milestones
1. **Provenance:** integrate a maintained C2PA verifier; validate signatures, manifest chain, signer trust, ingredient relationships, and AI-related assertions. Preserve raw verification outcomes and verifier version.
2. **Video:** select an AI-generated-video detector with documented training/evaluation data; sample frames consistently, track temporal evidence, test recompression/cropping/low resolution and real-world drift.
3. **Audio:** select a synthetic-speech/music detector with documented limitations; support language/accent/noise variation and manipulated real recordings.
4. **Fusion/calibration:** build a representative, rights-cleared benchmark; calibrate probabilities and thresholds; evaluate AUROC, precision/recall, Brier score, calibration error, false-positive rates by content type/language, and abstention coverage.
5. **Public beta:** privacy impact assessment, clear consent/retention policy, secure hosted API, rate limits, abuse reporting, model/version disclosure, accessibility, security review, extension-store review, and independent red-team testing.

## Architecture

```text
YouTube DOM (visible disclosure only)
          |
          v
Chrome/Edge MV3 content script ---- optional local/hosted Evidence API
                                          |
                  +-----------------------+-----------------------+
                  |                       |                       |
          C2PA verifier (future)   Video model (future)    Audio model (future)
                  |                       |                       |
                  +-----------------------+-----------------------+
                                          v
                               evidence normalization
                                          v
                              calibration + fusion gate
                                          v
                       Verified assertion / Likely / Unknown
```

## Privacy and release notes
- The extension currently sends the video ID and visible card text to the configured API. Use the local API for development.
- If a hosted service is added, disclose exactly what is collected, why, retention, deletion, and whether media leaves the device. Do not upload private/unlisted media by default.
- Minimize browser permissions and request remote host permissions only when needed. Do not market this build as a reliable detector or use its output for consequential moderation decisions.
