"""Strict fusion gate for future detector integrations.

A production adapter must pass independently validated/calibrated detector outputs.
This module does not itself inspect media and is not an AI detector.
"""
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class ModalityResult:
    modality: str
    probability_ai: float
    model_id: str
    calibration_id: Optional[str]
    evaluated_on: Optional[str]

@dataclass(frozen=True)
class FusionResult:
    label: str
    confidence: Optional[float]
    explanation: str


def fuse_video_audio(video: Optional[ModalityResult], audio: Optional[ModalityResult], threshold: float = 0.80) -> FusionResult:
    """Only emit a probabilistic label when both modalities are calibrated and agree.

    The threshold is a placeholder policy gate, not a claim that 0.80 is optimal.
    It must be chosen from validation data before public release.
    """
    results = [r for r in (video, audio) if r is not None]
    if not results:
        return FusionResult("AI status unknown", None, "No video/audio model result is available.")
    for r in results:
        if not 0.0 <= r.probability_ai <= 1.0:
            raise ValueError("probability_ai must be in [0, 1]")
    if any(not r.model_id or not r.calibration_id or not r.evaluated_on for r in results):
        return FusionResult("AI status unknown", None, "At least one model result lacks model/version, calibration, or evaluation metadata.")
    if video is None or audio is None:
        return FusionResult("AI status unknown", None, "Only one modality is available; this preview requires video and audio agreement before showing a probabilistic label.")
    if video.probability_ai >= threshold and audio.probability_ai >= threshold:
        # Conservative minimum rather than pretending the scores are independent.
        return FusionResult("Likely AI-assisted", min(video.probability_ai, audio.probability_ai),
                            "Both calibrated modality models exceeded the configured policy threshold. This remains probabilistic, not proof.")
    return FusionResult("AI status unknown", None, "Video/audio evidence did not meet the agreement policy. No human-made conclusion is inferred.")
