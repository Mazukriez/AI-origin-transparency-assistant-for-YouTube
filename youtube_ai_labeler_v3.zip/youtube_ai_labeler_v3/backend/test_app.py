from fastapi.testclient import TestClient
from app import app

client = TestClient(app)

def test_health_discloses_disabled_detectors():
    r = client.get('/health')
    assert r.status_code == 200
    assert r.json()['detectors']['disclosure_phrase'] == 'active'
    assert r.json()['detectors']['video_ai_classifier'] == 'not_configured'

def test_unknown_is_not_claimed_human_made():
    r = client.post('/v1/assess', json={'video_id':'abcdefghijk', 'visible_page_text':'ordinary video description'})
    assert r.status_code == 200
    assert r.json()['label'] == 'AI status unknown'
    assert r.json()['confidence'] is None
    assert 'does not mean human-made' in r.json()['explanation']

def test_disclosure_phrase_is_only_a_signal():
    r = client.post('/v1/assess', json={'video_id':'abcdefghijk', 'visible_page_text':'Altered or synthetic content'})
    assert r.status_code == 200
    assert r.json()['label'] == 'Disclosure signal'
    assert r.json()['evidence'][0]['verified'] is False
    assert 'not independently verified' in r.json()['explanation']

def test_invalid_video_id_rejected():
    r = client.post('/v1/assess', json={'video_id':'bad id!', 'visible_page_text':''})
    assert r.status_code == 422

def test_capabilities_says_video_audio_are_inactive():
    data = client.get('/v1/capabilities').json()
    assert 'video_frame_ai_detection' in data['inactive']
    assert 'audio_ai_detection' in data['inactive']
