import pytest
from fusion import ModalityResult, fuse_video_audio

def item(modality, p=0.91, calibration='cal-v1'):
    return ModalityResult(modality, p, f'{modality}-model-v1', calibration, 'eval-set-2026-01')

def test_requires_both_modalities():
    r = fuse_video_audio(item('video'), None)
    assert r.label == 'AI status unknown'
    assert r.confidence is None

def test_requires_calibration_metadata():
    r = fuse_video_audio(item('video', calibration=None), item('audio'))
    assert r.label == 'AI status unknown'

def test_agreement_is_probabilistic_not_proof():
    r = fuse_video_audio(item('video', .92), item('audio', .84))
    assert r.label == 'Likely AI-assisted'
    assert r.confidence == .84
    assert 'not proof' in r.explanation

def test_disagreement_does_not_call_human_made():
    r = fuse_video_audio(item('video', .91), item('audio', .33))
    assert r.label == 'AI status unknown'

def test_rejects_invalid_probability():
    with pytest.raises(ValueError):
        fuse_video_audio(item('video', 1.2), item('audio'))
