chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'YTAL_ASSESS') return false;
  (async () => {
    const videoId = String(message.video_id || '');
    const pageText = String(message.visible_page_text || '').slice(0, 12000);
    const stored = await chrome.storage.local.get({ ytalApiBase: 'http://127.0.0.1:8765' });
    const apiBase = String(stored.ytalApiBase || 'http://127.0.0.1:8765').replace(/\/$/, '');
    const url = new URL(apiBase);
    if (!['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.protocol !== 'http:') {
      throw new Error('This preview only permits a local loopback API.');
    }
    const response = await fetch(`${apiBase}/v1/assess`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ video_id: videoId, visible_page_text: pageText }),
      signal: AbortSignal.timeout(1800)
    });
    if (!response.ok) throw new Error(`Evidence API returned HTTP ${response.status}`);
    return await response.json();
  })().then(data => sendResponse({ ok: true, data })).catch(() => sendResponse({ ok: false }));
  return true;
});
