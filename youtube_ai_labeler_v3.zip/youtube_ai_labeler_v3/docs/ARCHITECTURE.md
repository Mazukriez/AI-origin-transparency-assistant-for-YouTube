# Architecture and trust boundaries

## Components

1. **MV3 content script** — reads only rendered YouTube DOM text and adds small labels. It does not intercept video streams or download media.
2. **MV3 service worker** — reads the local API setting and makes the API request from the extension context. It enforces loopback-only HTTP in this preview.
3. **Evidence API** — validates request shape, matches disclosure text, and exposes capability status. It does not claim a forensic verdict.
4. **Future provenance adapter** — a separate service/library should parse C2PA manifests, validate signatures and ingredient/manifest chains, apply a documented signer trust policy, and return signed assertion details.
5. **Future video/audio model adapters** — separately versioned inference services must return model ID, calibrated score, calibration version, evaluation-set version, supported input conditions, and abstention reason.
6. **Fusion policy** — `backend/fusion.py` is an example gate. It requires both video and audio outputs with metadata before a probabilistic label. It is not wired to media inference and its threshold is only a placeholder.

## Trust levels

- `verified=true` must only be set by a cryptographic verifier that checked the relevant credential and trust policy. A DOM phrase must never set it.
- A detector probability is probabilistic even after calibration. It must not be represented as verified provenance.
- A missing credential, unavailable model, unsupported language, or conflicting model output must produce unknown/abstention, not a human-made verdict.
- Do not merge scores as if independent unless that assumption has been empirically justified. Validate the full fused system on a held-out dataset.

## Deployment boundary

This package is a local developer preview. Before a hosted API, add authentication, rate limiting, TLS, request/body limits, structured logs with data minimization, monitoring, retention/deletion controls, privacy notices, incident response, and a reviewed model supply chain. Do not expose the development API to the public internet.
