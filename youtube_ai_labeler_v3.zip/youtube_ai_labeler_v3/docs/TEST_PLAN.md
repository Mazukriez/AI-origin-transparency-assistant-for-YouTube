# Test plan — public beta readiness

## A. Current automated tests
- API health/capability disclosure: detector status must be explicit.
- Visible disclosure phrase: output is `Disclosure signal`, `verified=false`, and no confidence score.
- Missing evidence: output is `AI status unknown`, never `human-made`.
- Input validation: reject malformed YouTube video IDs.
- Fusion: both modalities and model/calibration/evaluation metadata are required; disagreement abstains; probabilities outside [0,1] are rejected.

## B. Browser smoke tests (manual)
1. Load unpacked extension in Chrome stable and current Edge.
2. Open YouTube home, search results, Shorts, channel pages, playlist pages, and a watch page.
3. Confirm labels survive SPA navigation and do not duplicate after scrolling/re-rendering.
4. Confirm pages without a disclosure show `AI status unknown`.
5. Confirm disclosure text is blue `Disclosure signal`, not green verified.
6. Stop local API and verify no crash/hanging UI.
7. Change API URL to invalid URL and confirm safe failure; remote HTTP should be rejected by settings.
8. Test browser zoom, dark/light YouTube themes, keyboard navigation, tooltip readability, and screen readers.

## C. Detector validation required before public probabilistic labels
- Split by creator/source and time to prevent leakage; retain untouched external test set.
- Include human-made, AI-generated, AI-assisted, dubbed, deepfake, mixed-edit, animation, screen capture, low bitrate, short clips, music, speech, and no-speech videos.
- Include major languages, accents, genres, devices, and compression pipelines.
- Track precision, recall, false-positive rate, false-negative rate, AUROC, Brier score, expected calibration error, abstention rate, and subgroup performance.
- Run adversarial tests: re-encoding, cropping, overlays, pitch shifts, background noise, frame interpolation, dubbing, and detector-evasion edits.
- Establish documented threshold policy and confidence intervals; label as probabilistic, not verified.

## D. Security/privacy
- Threat model prompt/page-text injection, malicious API responses, SSRF, file upload abuse (if later added), API abuse, dependency vulnerabilities, and model supply-chain risk.
- Enforce HTTPS for hosted API, authentication/rate limits, request size limits, strict CORS, retention limits, user deletion, and audit logging without raw media by default.
- Independent security and privacy review before store publication.
