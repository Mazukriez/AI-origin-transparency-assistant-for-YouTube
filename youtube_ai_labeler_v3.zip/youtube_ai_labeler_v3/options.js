const api = document.getElementById('api');
const status = document.getElementById('status');
chrome.storage.local.get({ ytalApiBase: 'http://127.0.0.1:8765' }, value => { api.value = value.ytalApiBase; });
document.getElementById('save').addEventListener('click', () => {
  const value = api.value.trim().replace(/\/$/, '');
  let url;
  try { url = new URL(value); } catch (_) { status.textContent = 'Enter a valid URL.'; return; }
  if (url.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)) {
    status.textContent = 'This preview only supports a local loopback API (127.0.0.1, localhost, or ::1).'; return;
  }
  chrome.storage.local.set({ ytalApiBase: value }, () => { status.textContent = chrome.runtime.lastError ? 'Could not save settings.' : 'Saved.'; });
});
